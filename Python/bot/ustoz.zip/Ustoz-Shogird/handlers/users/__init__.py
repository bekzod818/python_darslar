from . import help
from . import start
from . import newpost
from . import confirm
# from . import auto
# from . import echo